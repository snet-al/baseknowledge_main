# Installation and migration

This guide targets local Codex environments. Apply the same instruction files in the actual environment used by any remote or hosted task; do not assume that your laptop's home directory is transferred automatically.

Official sources checked for this revision:

- [Custom instructions with AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md)
- [Build skills](https://learn.chatgpt.com/docs/build-skills)
- [Hooks](https://learn.chatgpt.com/docs/hooks)

## 1. Install the complete worldview globally

Codex's documented global instruction location is its home directory, normally `~/.codex`, or the directory set by `CODEX_HOME`. It reads a nonempty `AGENTS.override.md` in preference to `AGENTS.md` at that level. Instruction discovery happens at the start of a run/session; restart after replacing instructions.

Run the following from the extracted `snet-codex-worldview-v4` directory. This backs up a current file before replacement. Review or merge any unrelated existing instructions rather than discarding them.

```bash
CODEX_DIR="${CODEX_HOME:-$HOME/.codex}"
mkdir -p "$CODEX_DIR"

if [ -f "$CODEX_DIR/AGENTS.md" ]; then
  cp "$CODEX_DIR/AGENTS.md" "$CODEX_DIR/AGENTS.md.backup.$(date +%Y%m%d-%H%M%S)"
fi

cp AGENTS.md "$CODEX_DIR/AGENTS.md"
```

Inspect `AGENTS.override.md` when it exists. Do not delete an intentional override blindly. A nonempty override can prevent the normal file from being the active global instructions.

The complete worldview stays in this file. A pointer saying only "load the skill" is not equivalent.

## 2. Install the updated skill in one scope

For personal use across local repositories, copy the complete skill directory to:

```text
~/.agents/skills/snet-engineering-worldview/
```

For a team-shared repository workflow, use:

```text
<repository>/.agents/skills/snet-engineering-worldview/
```

Choose one active copy of this named skill for a given workspace. Codex documents that same-name skills are not merged; both may appear. Move backups out of `.agents/skills`, not into another discoverable subdirectory there.

Example personal installation, preserving any older directory outside discovery:

```bash
SKILL_NAME="snet-engineering-worldview"
SKILL_ROOT="$HOME/.agents/skills"
BACKUP_ROOT="$HOME/.agents-backups"
mkdir -p "$SKILL_ROOT" "$BACKUP_ROOT"

if [ -d "$SKILL_ROOT/$SKILL_NAME" ]; then
  mv "$SKILL_ROOT/$SKILL_NAME" \
     "$BACKUP_ROOT/$SKILL_NAME.$(date +%Y%m%d-%H%M%S)"
fi

cp -R ".agents/skills/$SKILL_NAME" "$SKILL_ROOT/$SKILL_NAME"
```

Also inspect repositories that may still contain the older `snet-engineering-lens` or an older same-name worldview skill. Archive redundant copies deliberately. Do not delete unrelated skills.

The name remains:

```text
$snet-engineering-worldview
```

Explicit invocation is useful for feature mapping and calibration. The description also permits implicit invocation, but the core worldview does not depend on either.

## 3. Keep repository guidance contextual

Keep repository `AGENTS.md` files focused on actual project facts: naming vocabulary, module locations, existing conventions, commands, contracts, and specific exceptions. Read the applicable global-to-project chain rather than assuming the global file is the only instruction source.

For a team that needs the same complete worldview without personal installation, it can be distributed through the repository's root `AGENTS.md`. Manage that as a deliberate source-controlled deployment of the same policy, not as an independently evolving second constitution.

## 4. Check the instruction budget

The documented default `project_doc_max_bytes` is 32 KiB. The v4 core file itself is below that value, but applicable repository and nested instructions also require room. Check the complete instruction chain for the actual workspace.

When a larger budget is genuinely necessary, merge this top-level key into the existing `config.toml`; do not overwrite the rest of the configuration or create duplicate keys:

```toml
project_doc_max_bytes = 65536
```

A larger budget is not a reason to duplicate the worldview in every directory. Restart Codex after configuration changes.

## 5. Optional lifecycle reinforcement

The core installation above is sufficient to install the worldview. The optional reminder is for users who retain the v3 hook approach. It does not run at token boundaries and does not guarantee compliance.

The hook reads the priority block marked inside the active global instructions. It does not maintain a separate copy of the philosophy, log prompts, call the network, scan repositories, mutate files, or block prompts.

Requirements: a Codex build supporting the documented hooks and `python3` available to its command environment. No Python runtime is needed for the core `AGENTS.md` or skill.

Copy the script:

```bash
CODEX_DIR="${CODEX_HOME:-$HOME/.codex}"
mkdir -p "$CODEX_DIR/hooks"
cp optional-hooks/snet_worldview_turn.py "$CODEX_DIR/hooks/snet_worldview_turn.py"
```

Merge the supplied `optional-hooks/hooks.json` entries into the active `hooks.json`. Do not replace unrelated hooks. When migrating from v3, replace the old SNET event entries rather than adding duplicate reminders for the same event.

The command respects `CODEX_HOME`. The script also respects a nonempty global override: if that file lacks the marked SNET block, it injects nothing rather than reintroducing a deliberately overridden policy.

Current official documentation says hooks are enabled by default and non-managed hooks require review and trust. Existing local or managed configuration may disable them. Review the hook through the client hook controls, such as `/hooks` where available, before relying on it. The package has no reason to change unrelated permissions or approval policies.

## 6. Validate loading, then validate judgment

Start a new session in a representative repository. Ask:

```text
List the instruction files active for this task. State the four SNET
priorities in order, and explain where the full worldview lives.
Do not edit any files.
```

Then use a real small task:

```text
$snet-engineering-worldview Map this feature before proposing changes.
Show the canonical names, critical function and variable flow, weighted
relationships, actual read coverage, and consequential unknowns.
Do not edit yet.
```

Confirm that paths and symbols actually exist, names are not merged incorrectly, critical dependencies were followed, and the result fits the repository. An instruction summary is a loading smoke check, not proof that every later answer will align.

Use the included calibration cases and rubric to compare behavior across tasks. This package does not claim a live Codex validation result.
