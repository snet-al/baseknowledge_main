# SNET Codex Worldview — v4

The core model is deliberately ordered:

1. Naming and meaning.
2. Multidimensional understanding.
3. Functions and their organization.
4. A task-scoped semantic feature map before material decisions or changes.

The purpose is useful engineering value: code that communicates its meaning, can be reused and maintained incrementally, and fits the team and operating environment.

## Main files

- [AGENTS.md](AGENTS.md) — the complete persistent worldview; independent of skill activation.
- [SKILL.md](.agents/skills/snet-engineering-worldview/SKILL.md) — the applied mapping and engineering method, retaining the existing skill name.
- [Installation](INSTALLATION.md) — global and repository placement, safe migration, overrides, and optional hooks.
- [Review notes](REVIEW_NOTES.md) — what was read, what changed, and the distinction between explicit user preferences and editorial interpretations.
- [Validation report](VALIDATION.md) — checks actually performed and what has not been validated.

## Supporting skill resources

The skill includes an explicit map contract, a reusable template, a complete small worked example, a working axis catalog, twenty calibration cases, and an ordered alignment rubric.

These are resources for applying the worldview, not another place where mandatory core beliefs are hidden. The `AGENTS.md` remains sufficient to state the full philosophy when the skill is not selected.

## What changed from the previous kits

Naming is treated as a responsibility and abstraction contract, not only a search aid. Reuse is a positive engineering goal that begins with meaningful functions; the kit does not equate simplicity with avoiding abstraction. The feature map uses qualified symbol identity, explicit value flow, typed relations, separate semantic and behavioral weights, and honest coverage.

The design keeps the later conversation's project-consistency and non-TDD decisions even though the public Clean Code lesson still contains older material. It removes unsupported assumptions about SNET's default architecture and avoids claims of mathematical independence or token-by-token enforcement.

Optional hooks are provided for continuity with v3, but are not required. They repeat the marked priority block from the installed global instructions instead of maintaining a separate static philosophy string.

## Installation at a glance

For a personal worldview across local repositories:

```text
AGENTS.md -> $CODEX_HOME/AGENTS.md
            (normally ~/.codex/AGENTS.md)

.agents/skills/snet-engineering-worldview/
         -> ~/.agents/skills/snet-engineering-worldview/
```

Read the installation guide before replacing an existing file. Keep backups outside skill-discovery directories. Do not install two different versions with the same skill name in personal and repository scopes.

For team use, the same skill can instead be placed in the repository's `.agents/skills/`. Repository instruction placement should match the environment in which Codex runs; a file on one developer's laptop is not automatically available in a remote task environment.

## Limits

This package supplies instructions, examples, and an optional lifecycle reminder. It does not install a graph engine, compute embeddings, train a model, guarantee exhaustive static analysis, or execute a filter around every generated token.

Behavioral alignment must be assessed on real tasks. The validation report distinguishes structural checks from live Codex execution.
