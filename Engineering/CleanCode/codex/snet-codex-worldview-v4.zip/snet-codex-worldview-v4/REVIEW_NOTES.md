# Review Notes — SNET Worldview v4

## Review scope

This revision compares the visible conversation, relevant retrieved prior programming context, the two public SNET engineering documents, the attached updated Clean Code lesson, the v2 worldview skill and its references, and the v3 global `AGENTS.md` and hook package.

It is not a claim to have read a complete export of every conversation in the user's account or inspected SNET's application repositories. No repository architecture is inferred merely from earlier assistant statements.

Public source pages were read on September 6, 2026, as served by the web tool. They are `main` URLs, not commit-pinned snapshots. No remote GitHub files were changed.

## Sources and how they were used

### A. SNET Engineering README

[Engineering/README.md](https://github.com/snet-al/baseknowledge_main/blob/main/Engineering/README.md)

Relevant sections: Engineering; Creating value; value per line; value per module; abstraction layers and structure.

The document emphasizes product value, readable and optimized code, collaboration and junior integration, reuse, maintainability, and incremental construction from functions toward larger units. It also separates business-logic work from optimization as overlapping but distinct concerns.

These points justify restoring positive guidance about useful reuse and reader value. They do not justify repeating the document's informal reading/writing percentage as a universal measured fact; v4 makes no such quantitative claim.

### B. SNET Clean Code README

[Engineering/CleanCode/README.md](https://github.com/snet-al/baseknowledge_main/blob/main/Engineering/CleanCode/README.md)

Relevant sections: authors and readers; naming as the root of programming; why/what/how; abstraction knowledge; multidimensional viewpoints; functions; the FizzBuzz progression; formatting and team rules.

An earlier retrieval returned the older lesson with a testing section. The final direct raw-file check returned the updated 619-line README: Parts 1–4 cover naming, multidimensional principles, functions, and formatting/consistency/existing projects, with no separate testing chapter. The final revision is aligned with that updated source and the user's explicit instructions. The differing retrievals are not evidence that a commit occurred during this review; no commit history was verified.

### C. User instructions in this conversation

The explicit decisions preserved are:

- Naming has the highest priority.
- Multidimensional understanding is second.
- Functions and their grouping are third.
- A feature-specific map of code, variables, and weighted relationships is mandatory before material action.
- The worldview belongs in always-loaded instructions, not solely in an optional skill.
- Entering an existing project requires synchronizing with its conventions before introducing new paradigms.
- Testing is not a governing principle of software logic; the later lesson removes the testing section.
- The knowledge base must support junior learning as well as SNET's longer-term engineering foundation.

These are user statements, not newly inferred preferences.

### D. Previous generated artifacts

Reviewed the complete attached v3 `AGENTS.md` and v2 `SKILL.md`, the v2 worldview and calibration references available in the package, the updated Clean Code lesson, and the v3 hook/configuration files.

They were treated as implementations to improve, not independent proof of the user's beliefs. In particular, a previous assistant's claim that SNET necessarily uses Nx, micro-frontends, or microservices is not a confirmed global preference.

### E. Current Codex documentation

- [AGENTS.md instruction discovery](https://learn.chatgpt.com/docs/agent-configuration/agents-md)
- [Skill loading, metadata, and paths](https://learn.chatgpt.com/docs/build-skills)
- [Lifecycle hooks](https://learn.chatgpt.com/docs/hooks)

These sources support installation and lifecycle behavior, not the validity of SNET's engineering philosophy. The kit keeps core guidance in `AGENTS.md`, an applied method in the skill, and optional lifecycle reminders outside the required installation.

## What changed and why

### 1. Naming is a semantic contract, not just search relevance

The v3 file correctly gave names first priority, but operational detail leaned heavily toward discovery. The new version makes the naming contract explicit: purpose, owner, abstraction level, permitted knowledge, meaning, and material use constraints.

Names guide investigation. Source behavior establishes what currently happens; requirements establish what should happen. This corrects the risk of treating observed behavior as necessarily correct.

### 2. Restore the constructive side of reuse

Earlier files emphasized the cost of abstraction and the danger of sharing unrelated code. Those warnings remain useful, but alone they can produce an overly defensive agent.

The Engineering README positively values reuse. The new version actively seeks meaningful functions, stable shared rules, and incremental composition. It permits a valuable named abstraction with one current caller, while still requiring a real reason to create broader shared packages or frameworks.

### 3. Keep the worldview order consistent across artifacts

The v2 skill and rubric emphasized general context and architecture before naming, and used a summed assessment over several categories. The v3 global file had the later four priorities, but the old skill could still express a different ordering.

V4 uses the same four priorities in the global instructions, skill, calibration rubric, and optional reminder. Correctness and safety remain validity conditions, not low-ranked aesthetic criteria.

### 4. Map symbols and behavior, not just names or files

The new map uses qualified identities, variable lifecycles, source-of-truth relations, data transformations, function contracts, effects, and cross-boundary consumers. Same-spelling variables remain distinct nodes.

A file inventory is insufficient. The map must explain how the feature works and how the requested change can affect it.

### 5. Separate semantic weight, behavioral relevance, and evidence

The prior `P = (N, A, F)` scores were an authored heuristic, not calibrated measurements. V4 uses named ordinal categories and explicit evidence instead of numbers that can suggest unsupported precision.

Naming remains the primary discovery signal. An authorization function or mutation with a vague name remains mandatory when its behavior lies on the critical path. A high lexical match cannot exclude a verified dependency.

### 6. Make read coverage honest and maps reusable

V4 distinguishes full-file reads, ranges, inspected contracts, unread candidates, and exclusions. It prevents claims of exhaustive inspection based on snippets.

Follow-up tasks reuse validated context and inspect the delta. Critical gaps remain blockers. The map is updated when source or requirements change; it is not a reason to scan every unrelated file on every message.

### 7. Preserve the deeper function lesson

The FizzBuzz progression is interpreted as incremental clarification of conditions, named results, and communication boundaries. It is not an absolute ban on `else`, a requirement for zero arguments, or proof of fewer runtime output calls.

Function grouping remains evidence of the engineer's view of the feature, without forcing Functional Programming or a particular folder architecture.

### 8. Preserve project coherence without making it absolute

The new file preserves synchronization with existing conventions. It also distinguishes logical modularity from physical deployment and avoids introducing new operational machinery without a concrete need.

A demonstrated bug, access-control defect, or integrity failure is not protected by convention. Broad changes still require an authorized and understandable migration boundary.

### 9. Keep all core beliefs in AGENTS.md

The skill now focuses on applying the worldview: discovery, weighted mapping, bounded decisions, verification, and calibration. It no longer owns a competing full constitution with a different order.

No vector database, graph server, embedding model, runtime script, or skill invocation is required to state the core philosophy.

### 10. Optional reminders use one source

The new optional hook extracts the marked priority block from the active global instructions rather than maintaining a separate philosophy string. It respects `CODEX_HOME` and the global override choice, and does not log prompts or mutate files.

It remains a lifecycle reminder, not a token-level filter or a guarantee of alignment. Current hook documentation, rather than the previous reply, governs feature support and trust requirements.

## Editorial interpretations, not additional user commandments

The following are operational design choices in this revision: qualified symbol IDs; named weight categories; read-coverage states; exact map templates; the twenty calibration scenarios; and the optional marker-based reminder implementation.

They implement the user's requested worldview but are not presented as independently confirmed universal SNET standards. A later explicit correction can refine them at the correct scope.

## What was deliberately not added

No default Nx architecture, mandatory microservices, compulsory CI/CD, required vector database, mandatory TDD, universal no-`else` rule, automatic global renames, hidden dependency injection to reduce parameter counts, or claim of permanent model training.

No new personal facts, organizational policies, or unseen repository structures are inferred. No promise is made that every generated token has been mechanically checked against the worldview.
