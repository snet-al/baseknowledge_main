#!/usr/bin/env python3
"""Optionally repeat AGENTS.md's own priority block at Codex lifecycle events.

No prompt logging, network, repository scan, shell execution, or file mutation.
A missing/malformed marker block yields no added context; this reminder never
blocks a prompt. Core worldview behavior does not depend on this script.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys

START = "<!-- snet:turn-reminder:start -->"
END = "<!-- snet:turn-reminder:end -->"
SUPPORTED_EVENTS = {"UserPromptSubmit", "SessionStart"}
MAX_REMINDER_CHARS = 3500


def active_global_instructions(codex_home: Path) -> str:
    """Respect the documented nonempty global override preference."""
    for name in ("AGENTS.override.md", "AGENTS.md"):
        path = codex_home / name
        if path.is_file():
            text = path.read_text(encoding="utf-8")
            if text.strip():
                return text
    return ""


def extract_reminder(text: str) -> str:
    if text.count(START) != 1 or text.count(END) != 1:
        return ""
    start = text.index(START) + len(START)
    end = text.index(END)
    if end <= start:
        return ""
    reminder = text[start:end].strip()
    # Never emit a truncated policy or an unbounded instruction document.
    return reminder if len(reminder) <= MAX_REMINDER_CHARS else ""


def main() -> int:
    try:
        event = json.load(sys.stdin)
        if not isinstance(event, dict):
            return 0
        event_name = event.get("hook_event_name")
        if not isinstance(event_name, str) or event_name not in SUPPORTED_EVENTS:
            return 0
        codex_home = Path(os.environ.get("CODEX_HOME") or Path.home() / ".codex").expanduser()
        reminder = extract_reminder(active_global_instructions(codex_home))
        if reminder:
            json.dump(
                {"hookSpecificOutput": {
                    "hookEventName": event_name,
                    "additionalContext": reminder,
                }},
                sys.stdout,
                ensure_ascii=False,
            )
            sys.stdout.write("\n")
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"SNET optional reminder skipped: {type(exc).__name__}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
