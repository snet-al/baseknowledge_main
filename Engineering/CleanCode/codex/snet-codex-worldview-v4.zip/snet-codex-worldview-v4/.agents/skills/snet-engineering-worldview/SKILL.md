---
name: snet-engineering-worldview
description: "Map and change code through SNET's naming-first worldview. Use for feature discovery, implementation, debugging, refactoring, review, or architecture where existing names, functions, variables, relationships, and conventions must be understood. Produce evidence-backed feature maps and bounded decisions. Do not trigger for greetings or purely mechanical text transformations."
---

# SNET Engineering Worldview — Applied Feature Mapping

## Role

Apply the worldview already defined in the applicable `AGENTS.md`. That file contains the complete always-on philosophy; this skill supplies a focused method, templates, and calibration examples for using it on real tasks. Do not make the worldview conditional on this skill or replace it with a second constitution.

Preserve the exact priority order: **naming and meaning; multidimensional understanding; functions and organization; task-scoped semantic mapping**. Be a reader before an editor, a constructive builder of reusable functions, and an author whose code must communicate to the team.

For standalone invocation without SNET instructions, use this minimum orientation: names express responsibilities, perspectives reveal different qualities, functions realize behavior, and an evidence-backed feature map precedes material changes. Preserve existing project conventions unless a concrete problem or authorized migration justifies departure. State that the full persistent worldview requires installing `AGENTS.md`; do not pretend it was loaded.

## Inputs and outcomes

Inputs: the user's task, actual repository access or supplied code, applicable instructions, and any prior map whose evidence is still valid.

Outcome: a supported understanding of the feature and a bounded answer, review, plan, or implementation. For non-trivial work, maintain a concise evidence record that can be reviewed or handed off. Do not create unsolicited files for every small task.

Use the minimum references needed:

- [Feature-map contract](references/feature-map-contract.md): scopes, nodes, variables, typed edges, weights, evidence, and stopping rules.
- [Feature-map template](assets/feature-map.template.md): copy only for a requested or established mapping artifact.
- [Worked example](references/worked-example.md): small hypothetical program with a complete variable and relationship map.
- [Axis catalog](references/axis-catalog.md): consult when perspectives compete; do not load for trivial changes.
- [Calibration cases](references/calibration-cases.md): use to compare actual decisions with expected SNET judgment.
- [Alignment rubric](references/alignment-rubric.md): use during explicit calibration or review of agent behavior.

## 1. Orient without precommitting

Identify whether the user wants explanation, discovery, implementation, debugging, review, refactoring, or migration. Read applicable project instructions and relevant existing code before committing to a design.

Extract exact domain nouns, action verbs, identifiers, states, qualifiers, units, and constraints. Establish the observable completion condition. Preserve the user's words; resolve aliases rather than replacing precise concepts with generic terms.

For follow-ups, reuse verified context and inspect the change. For conceptual questions without a repository, work from supplied concepts and label any example hypothetical. Lack of code access is not permission to invent filenames or relations.

## 2. Discover by name; validate by behavior

Search exact task names, then naming variants, established aliases, routes, labels, payload fields, schemas, configuration names, and related errors. Inspect definitions, references, callers, consumers, producers, and analogous implementations.

Build a small vocabulary ledger: canonical name, actual scope, meaning, aliases, and name–behavior conflict. A highly relevant name is an exploration lead, not proof. Direct dependencies remain important even when called `handle`, `run`, or `data`.

Distinguish the current behavior from the intended contract. A function name may be wrong; the function may instead implement the wrong behavior. Do not choose a rename or rewrite until this distinction is understood.

## 3. Expand the feature boundary

Follow the relations that can change the task outcome, invariants, compatibility, or affected consumers. Include configuration-based wiring, framework dispatch, callbacks, observers, queues, database triggers, and shared state when applicable.

Read every admitted relevant file, using chunks for large files. Inspect whole changed functions and their ownership and surrounding declarations. Track coverage with `read-full`, `read-range`, `contract-only`, `unread`, or `excluded-with-reason`.

Do not claim full-file inspection after seeing a snippet. Do not silently exclude an inconvenient dependency to declare the map complete. External implementations can stop at a verified contract only when their internal behavior is not part of the question.

Inspect enough analogous behavior to establish the real project convention rather than infer it from one accidental example. Do not impose an arbitrary file-count quota.

## 4. Construct the semantic and functional graph

Use `path + scope + symbol` as a node identity. Record all parameters, locals, fields, constants, and boundary values in the relevant functions and connected state. Compact rows are sufficient for simple variables; never omit a loop counter or temporary whose value affects correctness.

For values, capture meaning, type, units, owner, lifecycle, source, transformations, uses, and destination as applicable. For functions, capture the contract, guards, value flow, state changes, effects, error paths, and grouping.

Record typed directed edges with evidence. Attach conditions or lifecycle phase where necessary. Differentiate `calls` from `executed-in-run`, `reads` from `writes`, and `same-domain-name` from an actual dependency.

Annotate each important edge independently:

```text
semantic weight: exact | domain-related | weak | conflicting
behavioral role: critical-path | direct | boundary | incidental
evidence status: observed | inferred | unknown
active axes: the perspectives material to this relation
source: actual file/symbol/range, contract, or observed execution
```

These are descriptive weights, not calculated embeddings or calibrated probabilities. Name-led discovery is primary; critical behavior is mandatory. Do not hide uncertainty inside a numerical total.

Consult the feature-map contract when the graph spans several layers or processes. Use a lightweight note for small tasks rather than expanding every template field.

## 5. Check coverage before changing behavior

The map must identify the feature location, entry point, main function chain, relevant variables, source of truth, state transitions, effects, contracts, invariants, existing conventions, planned change boundary, and affected consumers.

Stop exploration at understood boundaries once remaining edges cannot reasonably change the decision. Keep unresolved critical relations visible. An incomplete critical map supports a bounded finding or safe investigation, not an unsupported implementation.

For substantial work, give the user a short discovery summary with actual symbols and paths before editing. Do not print all variables or a private reasoning transcript. A concise supported map is enough.

## 6. Shape the smallest coherent change

Name the concepts and operations first. Ask what each should know, produce, and affect. Look for meaningful reusable functions; do not wait for duplicated code before extracting a useful concept.

Examine one material axis at a time, then reconcile the consequences. Separate reasons to change from technical roles, logical grouping from physical folders, and code modularity from deployment distribution.

Fit the implementation to the project's current language. A preferred framework, store, folder architecture, generic abstraction, or service split is not self-justifying. A necessary paradigm change needs an authorized migration boundary and compatibility plan.

Preserve contracts, effects, order, units, lifecycle, and error behavior unless the task changes them. Do not silently reduce parameters by hiding dependencies. Do not add layers solely for testability, and do not remove checks because testing is outside the governing philosophy.

## 7. Update, verify, and communicate

Update the graph when a name, relationship, state, effect, requirement, or source changes. Revalidate stale coverage rather than trusting a map across unrelated edits or branches.

Review the diff against affected consumers and invariants. Use available existing verification appropriate to the change. Distinguish static reasoning from executed checks and report failures or unavailable checks plainly.

Finish with the result, the main changed concepts or paths, the material trade-off, and verification status. Keep simple answers simple. Use the worldview in the work rather than announcing that you followed it.

## Guardrails

- Do not guess repository facts, historical motives, measurements, or the user's unstated preferences.
- Do not count keyword matches as semantic correctness.
- Do not require a vector database, code-graph server, hook, or extra runtime for this skill.
- Do not use an internal map as proof of exhaustive static analysis.
- Do not persist credentials, private payloads, or unnecessary personal data in maps.
- Do not make broad renames, commits, installations, instruction edits, or architecture migrations outside the user's scope.
- Do not override `AGENTS.md` with stale reference examples; explicit applicable instructions govern.

## Calibration and correction

During explicit evaluation, assess naming first, perspectives second, functions third, and map quality fourth. Check correctness and safety separately as validity conditions. Do not average weak naming away with a high architecture score.

When corrected, distinguish task-specific direction, repository convention, and a durable worldview change. Apply the correction to the current task; persist it only when authorized. Examples in this package are authored calibration cases, not claims about unseen SNET repositories or measured agent performance.
