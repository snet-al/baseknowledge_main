# Task-Scoped Semantic Feature Map

## What this record represents

A map is an evidence-backed description of the feature relevant to one task. It is not a repository-wide inventory, proof of a complete call graph, a vector database, or a transcript of private reasoning.

Conceptually:

```text
Map(task, revision) = nodes + typed relationships + semantic annotations
                   + coverage + constraints + unresolved questions
```

This notation describes the artifact. It does not claim that vectors, graph closure, or embeddings have been computed by a tool.

The mandatory mapping obligation lives in `AGENTS.md`. This reference defines a more explicit representation for complex work.

## 1. Task and scope

Record the task in the user's domain vocabulary, its observable outcome, relevant non-goals, and hard constraints. Identify the repository and revision when actually available. If the working tree is dirty, note relevant changed paths instead of implying that the commit hash fully identifies the inspected source.

Separate three boundaries:

- **Discovery boundary:** candidate code being investigated.
- **Evidence boundary:** code or contracts actually read well enough to support conclusions.
- **Edit boundary:** code authorized and proposed to change.

These boundaries need not match. Reading an upstream consumer does not authorize editing it. A file found by search is not automatically understood.

## 2. Vocabulary and identity

Start with exact task words. Record canonical project terms, aliases, units, lifecycle qualifiers, ownership, and homonyms. A table column, API field, and local variable may refer to related values without being the same symbol or contract.

Node identity should be stable enough for the current inspection:

```text
relative/path::containing-class-or-function::symbol
```

Attach the current location separately. Line numbers may move after an edit. Use a qualified symbol and revalidated range rather than treating an old line number as a permanent identifier.

Never merge nodes solely because they share a name. Use `aliases`, `derived-from`, or `serialized-as` edges to explain relationships.

## 3. Node records

### Named value

Record, where applicable:

```text
id / name / kind / location
meaning / type-or-shape / unit / owner / lifecycle
source-of-truth / producer / transformations / readers / writers / destination
status: observed | inferred | proposed | unknown
semantic conflicts / unresolved questions
```

Cover every declared parameter, local, relevant field, constant, destructured binding, and captured value involved in the feature path. Include short names and loop bounds when behavior depends on them. A trivial local may use a single compact row; it must not disappear simply because it is inconvenient to explain.

Track absence and representation when relevant: null versus missing, zero versus false, identifier versus loaded entity, units, rounding, precision, timezone, or current versus historical state. Do not invent such distinctions where the code and task do not require them.

### Function or operation

Record its named purpose, owner, parameters, return contract, preconditions, result, state reads/writes, calls, effects, failure behavior, ordering requirements, and abstraction level. Identify whether it calculates, decides, coordinates, adapts, persists, presents, or performs another project-specific role.

### Boundary

Record the actual route, interface, schema, event, table, store, external service, process, or configuration boundary. Identify consumers, version or compatibility obligations, trust and tenant scope where relevant, and whether internal behavior was inspected or only the contract.

## 4. Relationship records

Use directed, typed relationships:

```text
source -> relationship -> target
```

Examples include `calls`, `passes-to`, `returns`, `reads`, `writes`, `derives-from`, `guards`, `persists`, `emits`, `consumes`, `configures`, `owns`, and `serialized-as`.

Attach the condition or phase when it matters: before commit, after validation, on retry, only for a certain state, only for one tenant scope. Distinguish a declared call from an observed runtime execution.

For dynamic dispatch, record the configuration or registration that resolves the handler. If it cannot be resolved, retain an explicit unknown edge; do not assert that no consumers exist because text search found none.

For side effects, understand source locations and runtime cardinality separately. Moving four mutually exclusive calls into one source location may improve readability without changing how many calls execute.

## 5. Weights and evidence

Use separate annotations, not an arbitrary sum:

| Field | Allowed descriptions | Meaning |
| --- | --- | --- |
| Semantic weight | exact, domain-related, weak, conflicting | Relationship to the task's canonical meaning and scope |
| Behavioral role | critical-path, direct, boundary, incidental | How the relation participates in behavior or change impact |
| Evidence status | observed, inferred, unknown | How the relation was established |
| Active axes | named relevant viewpoints | Why this relation matters for the decision |

An `observed` static call is not proof it occurred at runtime. State whether the evidence is a source definition, explicit binding, data-flow read, contract, or actual execution. A repeated convention supports an inference, not an invented historical explanation.

Use naming first to locate candidates. Then inspect relevant perspectives and functional proximity. A verified critical edge must be included even with weak semantic affinity. A conflicting name increases the need for investigation rather than lowering importance.

Numbers may be added only for an explicitly defined measurement or experiment. Without a model and data, neither a `0.92` confidence nor an `80%` semantic match is justified.

## 6. File coverage

Maintain a record with path, reason for inclusion, inspected scope, state, and any consequential gap:

- `read-full`: the entire file was read, including in several chunks.
- `read-range`: only the stated ranges or symbols were read.
- `contract-only`: a boundary definition was inspected; implementation was not.
- `unread`: discovered but not inspected.
- `excluded-with-reason`: investigated enough to justify being outside the task.

These states describe evidence, not task completion. A `read-full` file may still contain unresolved logic. A `contract-only` dependency may be sufficient when its contract is stable and its implementation is not in dispute.

Read every file admitted to the feature boundary. Complete any partial read that could change the conclusion. When access or context makes full coverage impossible, say so rather than narrowing the claimed boundary after the fact.

Do not enter credential values or unrelated sensitive records into a map. Configuration key names and their responsibilities are usually sufficient.

## 7. Stopping rule and blockers

Coverage is sufficient when the requested path, named values, invariants, effects, and affected consumers are supported, and unresolved edges terminate at understood external contracts or areas shown not to affect the task.

Do not stop at the first matching controller. Do not recursively inspect an entire framework when only its documented boundary matters. Stop at justified boundaries, not arbitrary hop counts.

An unknown authorization path, source of truth, mutation owner, public consumer, or transaction effect that could change correctness is a blocker for implementation. It may still permit a useful bounded answer explaining the finding or the next safe investigation.

## 8. Update and persistence

Revisit the map after changed symbols, new requirements, branch changes, runtime evidence, or invalidated assumptions. Record proposed nodes as proposed until implemented. Update moved ranges and changed contracts.

Keep compact working notes for small tasks. For substantial work, use the project's established documentation or scratch location, or an explicitly requested artifact path. Do not introduce a new repository folder simply to store every conversation map.

A handoff summary should retain task, verified vocabulary, critical path, effects, read coverage, unresolved questions, and the next bounded action. It should not pretend that an old map stays true after the source changes.
