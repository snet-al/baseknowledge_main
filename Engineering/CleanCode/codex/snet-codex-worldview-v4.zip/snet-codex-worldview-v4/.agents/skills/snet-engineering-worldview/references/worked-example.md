# Worked example: names, functions, and weighted relations

This is a deliberately small, hypothetical JavaScript example. It is not code found in a SNET repository. Its map covers the complete example, not an unseen application.

## Task

Produce one FizzBuzz label for each integer in an inclusive range and send each label to a caller-supplied output function. Keep calculation independent from output. Assume valid integer bounds; no new input-validation contract is being designed here.

## Complete example

```javascript
function formatFizzBuzzLabel(number) {
  let label = "";
  if (number % 3 === 0) label += "Fizz";
  if (number % 5 === 0) label += "Buzz";
  return label || String(number);
}

function printFizzBuzz(startNumber, endNumber, writeLine) {
  for (let number = startNumber; number <= endNumber; number += 1) {
    const label = formatFizzBuzzLabel(number);
    writeLine(label);
  }
}
```

The names describe two responsibilities: formatting a value and coordinating output. The coordinating function groups two steps into one coherent operation without mixing formatting details into the loop.

## Vocabulary and all declared values

| Qualified value | Meaning and lifecycle | Producer | Consumers |
| --- | --- | --- | --- |
| `example::formatFizzBuzzLabel::number` | Current integer being formatted; parameter | Caller binding | Divisibility conditions; numeric fallback |
| `example::formatFizzBuzzLabel::label` | Locally accumulated text; starts empty | Initialization; conditional appends | Return expression |
| `example::printFizzBuzz::startNumber` | Inclusive range start; parameter | Caller | Loop initialization |
| `example::printFizzBuzz::endNumber` | Inclusive range end; parameter | Caller | Loop continuation condition |
| `example::printFizzBuzz::writeLine` | Supplied effectful output operation; parameter | Caller | Invocation once per completed iteration |
| `example::printFizzBuzz::number` | Current loop value; local | Start bound; increment | Loop condition; formatter argument |
| `example::printFizzBuzz::label` | Formatter result for the current iteration; local constant | Formatter return | Output argument |

These are seven distinct declared value nodes. The two `number` nodes and two `label` nodes must not be collapsed merely because their spellings match. Parameter passing and return binding connect them.

`String` is an external built-in conversion contract, not another declared local. `formatFizzBuzzLabel` and `printFizzBuzz` are function nodes. A real caller of `printFizzBuzz` would need to supply and resolve `writeLine`; none is asserted to exist in a repository.

## Function view

| Function | Input | Result | State and effects | Grouping |
| --- | --- | --- | --- | --- |
| `formatFizzBuzzLabel` | One integer | A label string | Local accumulator only | Reusable formatting concept |
| `printFizzBuzz` | Start, end, output operation | No explicit result | Iteration and output callback | Coordinating operation |

Three explicit parameters in `printFizzBuzz` are preferable here to hiding range bounds or output selection in global state merely to achieve zero arguments.

## Representative typed, weighted relationships

All static evidence below is directly visible in the complete example. No runtime execution is claimed by this table.

| Relationship | Semantic weight | Behavioral role | Evidence and condition | Relevant perspectives |
| --- | --- | --- | --- | --- |
| `printFizzBuzz::startNumber -> initializes -> printFizzBuzz::number` | exact | critical-path | Source loop initialization | Meaning; value flow |
| `printFizzBuzz::endNumber -> bounds -> printFizzBuzz::number` | exact | critical-path | Source `number <= endNumber` | Meaning; correctness |
| `printFizzBuzz::number -> passes-to -> formatFizzBuzzLabel::number` | exact | critical-path | Explicit call argument | Meaning; functions |
| `formatFizzBuzzLabel::number -> guards -> formatFizzBuzzLabel::label` | domain-related | critical-path | Divisibility checks control appends | Local reasoning; state |
| `formatFizzBuzzLabel::label -> returns-to -> printFizzBuzz::label` | exact | critical-path | Return expression and caller binding; fallback can produce the result instead | Meaning; data flow |
| `printFizzBuzz::label -> passes-to -> printFizzBuzz::writeLine` | domain-related | critical-path | One callback site inside the loop | Effects; communication |
| `printFizzBuzz -> calls -> writeLine` | domain-related | boundary | Call is explicit; callback implementation is supplied externally | Dependency; effects |

The map keeps both semantic and operational meaning. A weak callback name would not make output behavior optional to inspect.

## The perspectives

**Naming:** `format` and `print` communicate different contracts. Renaming the formatter to a vague `process` would remove useful information without changing behavior.

**Multidimensional view:** separating formatting from output improves reuse and local reasoning, while adding one function boundary. This is a meaningful abstraction rather than a rule that every line needs its own function.

**Functions:** the formatter is useful even when the current program has one caller. The coordinator controls iteration and effects; it does not need a class, interface, service, or new package for this example.

**Mapping:** variable identity, range bounds, formatter return, and callback binding are all explicit. The supplied callback is an external boundary whose implementation would be investigated if the task concerned output failures.

## What the FizzBuzz lesson does and does not prove

Separate condition design, result construction, and output so that each concern can be improved consciously. A result variable helps communicate that separation.

An earlier mutually exclusive branch implementation could already have performed exactly one output call per number. This version consolidates the output source location; that alone is not a runtime performance claim.

Do not apply this example as a universal ban on `else`, early returns, multiple output operations, or established project conventions. Preserve the actual contract, order, and cardinality of effects.
