# Alignment Rubric

Use this for explicit calibration, not as mandatory output on every task. These are qualitative judgments, not measured probabilities or a claim of validated agent accuracy.

## Validity gate

First check the requested behavior, security, data integrity, contracts, scope, and truthfulness of evidence. A critical failure here makes the result unacceptable regardless of stylistic quality. Report defect severity separately from worldview alignment.

## Ordered assessment

Assess each priority as `aligned`, `partial`, or `missed`, with one concrete supporting example. Preserve the user's order:

1. **Naming and meaning:** Does the result use the actual domain vocabulary, distinguish scope and lifecycle, respect responsibilities, identify misleading names, and protect rename compatibility?
2. **Multidimensional understanding:** Does it distinguish perspectives and qualities, evaluate actual consequences, and avoid a universal pattern verdict?
3. **Functions and organization:** Does it make operations, value flow, state, effects, abstraction levels, grouping, and useful reuse understandable?
4. **Feature mapping:** Does evidence support the feature boundary, variable coverage, typed relationships, weights, relevant consumers, and stated unknowns?

Do not sum these into an equal-weight total. Strong architecture language does not compensate for a confused concept. Excellent naming does not compensate for an invalid implementation. Use the order to identify the first priority needing correction, while retaining all consequential findings.

## Cross-cutting checks

Does the change fit the existing project language? Does it add useful value for readers and maintainers? Are abstractions meaningful rather than either compulsory or forbidden? Is the operating model respected? Is verification reported honestly? Is the answer proportionate and useful to a junior when teaching is requested?

## Evidence-based evaluation record

```text
Scenario and inspected input:
Validity: acceptable / unacceptable / unresolved
1. Naming: aligned / partial / missed — evidence
2. Perspectives: aligned / partial / missed — evidence
3. Functions: aligned / partial / missed — evidence
4. Map: aligned / partial / missed — evidence
Project coherence and scope:
Verification actually performed:
First corrective lesson:
Correction scope: task / repository / durable worldview
```

A response that prints every priority but edits the wrong function is not aligned. A short response can be aligned when its names, judgment, and actual changes are well grounded.

The supplied cases have not been executed against a live Codex model in this package. Compare several representative real tasks and preserve counterexamples; do not conclude permanent behavioral alignment from one successful run.
