# Feature map: <task in the project's vocabulary>

Use only fields relevant to the task. This is an evidence record, not a private reasoning transcript. Replace placeholders with inspected facts; label proposals and unknowns.

## Task and boundaries

- Requested outcome:
- Exact task terms:
- Constraints and non-goals:
- Repository/revision or inspected working state:
- Discovery boundary:
- Evidence boundary:
- Authorized edit boundary:

## Vocabulary

| Canonical term | Meaning and scope | Actual aliases or boundary names | Ambiguity |
| --- | --- | --- | --- |

## Read coverage

| Actual path | Reason | Inspected ranges or symbols | Coverage state | Consequential gap |
| --- | --- | --- | --- | --- |

States: `read-full`, `read-range`, `contract-only`, `unread`, `excluded-with-reason`.

## Named values

| Qualified node | Kind and location | Meaning, type, unit, lifecycle | Producer / source of truth | Transformations and consumers | Status |
| --- | --- | --- | --- | --- | --- |

## Functions

| Qualified operation | Purpose and abstraction level | Inputs / result | State, guards, and effects | Callers / callees | Grouping and owner |
| --- | --- | --- | --- | --- | --- |

## Critical path

```text
<observed entry> -> <observed operations> -> <result and effects>
```

## Weighted relationships

| Source -> typed relation -> target | Condition or phase | Semantic weight | Behavioral role | Evidence status and actual location | Relevant axes |
| --- | --- | --- | --- | --- | --- |

## Invariants and boundaries

Record applicable contracts, affected consumers, state ownership, authorization or tenant scope, transactions, ordering, errors, retries, and compatibility.

## Decision summary

- Observed problem, not preference:
- Proposed names and function boundaries:
- Existing convention and fit:
- Main perspective and target quality:
- Material trade-off:
- Reuse or migration implications:
- Unknowns and implementation blockers:

## Verification and map freshness

- Source changes since inspection:
- Checks actually run and results:
- Checks not run or unavailable:
- Evidence to revalidate at handoff:
