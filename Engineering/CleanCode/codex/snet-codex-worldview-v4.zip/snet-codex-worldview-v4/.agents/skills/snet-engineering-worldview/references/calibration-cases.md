# Calibration Cases

These are authored evaluation scenarios, not reports of live Codex runs. Use them with real code or the exact hypothetical inputs stated. Evaluate the result and the evidence of inspection, not whether the response repeats SNET terminology.

## 1. A good-looking name conceals an effect

**Task:** Review `calculateInvoiceTotal`, which also persists an invoice.

**Expected:** Trace actual behavior and callers. Distinguish an incorrect implementation from a misleading name or mixed responsibilities. Preserve the public contract; suggest a bounded separation or accurate operation name when justified.

**Failure:** Praise the name, blindly trust it, or rename unrelated invoicing code.

## 2. Naming reveals abstraction, but context defines the promise

**Task:** Review SQL use by `PersonEntity` in a project that deliberately uses Active Record.

**Expected:** Establish the project's role for entities before judging dependencies. Explain the difference between this model and a persistence-free domain model. Do not introduce repositories throughout the project just to follow a suffix-based inference.

**Failure:** Declare SQL a universal SRP violation without reading the architecture.

## 3. A vague name contains a critical dependency

**Task:** Add cancellation behavior. The visible `cancelOrder` path calls `handle`, which enforces authorization.

**Expected:** Start from cancellation names, follow the explicit call, and include authorization as a critical relationship despite weak lexical similarity. Keep evidence and naming affinity separate.

**Failure:** Prune `handle` because its name has a low match score.

## 4. Same word, different value

**Task:** A frontend `total` is an estimate; backend `total` is the finalized amount.

**Expected:** Keep distinct qualified nodes. Map calculation, validation, rounding, and contract boundaries where present. Do not merge them solely because the identifier matches.

**Failure:** Treat them as one source of truth without evidence.

## 5. A meaningful function with one caller

**Task:** A screen contains a clearly separable rule that formats a domain status label. There is one current caller.

**Expected:** Consider a named function for readable responsibility and reuse potential. Keep it local unless broader ownership is real. A second caller is not required for a meaningful abstraction.

**Failure:** Reject extraction categorically as premature, or create a new generic package immediately.

## 6. Incremental reuse, not an abstraction ban

**Task:** Several operations share the same stable conversion rule and units.

**Expected:** Establish shared meaning and owner, extract a useful function with an explicit contract, and expand its grouping only when consumers justify it.

**Failure:** Keep harmful duplication because all abstractions are considered unnecessary, or build a plugin system before the shared function exists.

## 7. Similar code, independent knowledge

**Task:** Two contexts have visually similar eligibility checks but different owners and change rules.

**Expected:** Preserve distinct business policies. Share only a genuinely common lower-level concept, if one exists.

**Failure:** Extract a common policy solely to reduce repeated lines.

## 8. Follow the existing project language

**Task:** Add a Vue feature to a project using established `services/`, `stores/`, and `pages/` organization.

**Expected:** Map equivalent features, use their conventions, and explain any required departure. Do not move state into a feature folder just because co-location is preferred elsewhere.

**Failure:** Introduce `features/` and a new state library inside the task without a migration decision.

## 9. Paradigm independence

**Task:** The project has meaningful OO methods. The instruction says to see software as functions.

**Expected:** Map methods, state, contracts, and effects as operations while preserving the OO design where coherent.

**Failure:** Rewrite the project in a functional style because functions rank third.

## 10. Learn the actual FizzBuzz lesson

**Task:** Improve a branch-based FizzBuzz implementation whose branches already output once per number.

**Expected:** Separate conditions, result construction, and output where clearer. Distinguish reducing output sites from reducing executed output calls.

**Failure:** Claim fewer runtime calls without measurement, ban every `else`, or add a class hierarchy.

## 11. Zero arguments are not the objective

**Task:** A clear transformation receives two explicit inputs. Make it cleaner.

**Expected:** Judge whether the inputs express a coherent contract. Preserve explicit dependencies; do not hide them in global state to reach a numeric parameter target.

**Failure:** Use global state and call that cleaner because the function takes no arguments.

## 12. A feature spans more than its named folder

**Task:** Update an order status that is also handled by a configured observer and a queued listener.

**Expected:** Trace registration, state transitions, listener payloads, and effects. Mark unresolved dynamic wiring rather than asserting there are no consumers.

**Failure:** Read only the controller and folder matching the task name.

## 13. Mapping coverage must be honest

**Task:** Search results show two lines from each of twenty files.

**Expected:** Treat them as discovery snippets. Read required files and record actual coverage. Do not report twenty fully inspected files.

**Failure:** Claim exhaustive mapping from search results alone.

## 14. A follow-up should not restart the world

**Task:** After an inspected feature discussion, the user asks why one variable needs a unit suffix.

**Expected:** Reuse valid context, inspect only anything changed or uncertain, and answer through meaning and contract. No whole-repository rescan.

**Failure:** Spend the entire turn rebuilding the same map or insist on printing a graph.

## 15. Optimization is a focused concern

**Task:** A report has an evidenced slow query under the relevant workload.

**Expected:** Trace the value/query path, preserve business semantics, use an available execution plan or measurement, and isolate the justified improvement. A performance constraint cannot be dismissed as premature optimization.

**Failure:** Invent a percentage improvement, demand a new architecture without evidence, or ignore the latency requirement for stylistic purity.

## 16. Practical operation, not fashionable infrastructure

**Task:** An existing Docker Compose deployment needs reliable worker supervision; the user does not want a CI/CD migration or many extra services.

**Expected:** Understand process lifecycle and the existing deploy method. Evaluate supervision within that operating model, including shutdown, restart, logging, and failure behavior. Add boundaries only for a concrete benefit.

**Failure:** Replace the workflow with orchestration or CI/CD by default, or declare multiple containers universally wrong.

## 17. Testing is evidence, not the source of structure

**Task:** Implement a domain function in a repository with existing checks.

**Expected:** Derive the function from meaning, responsibility, behavior, and project conventions. Run relevant existing checks when possible. Do not impose TDD or erase verification.

**Failure:** Design an unnecessary mockable interface for every operation, skip available checks on philosophical grounds, or remove tests without authorization.

## 18. Correctness constrains consistency

**Task:** Existing handlers omit a required tenant restriction, and a new handler could copy them.

**Expected:** Preserve the access boundary in the new work, surface the existing risk with evidence, and define a bounded remediation or migration scope rather than silently copying the defect.

**Failure:** Preserve a demonstrated isolation failure because it is conventional.

## 19. Important name change crosses a public boundary

**Task:** Rename `cost` to `unitCostAtSale`, but `cost` is also an exported payload field.

**Expected:** Determine the real semantic distinction and all consumers. A local identifier may be renamed while preserving the external key, or a compatibility migration may be needed.

**Failure:** Global search-and-replace with no consumer analysis.

## 20. Do not learn assistant guesses as user philosophy

**Task:** An older assistant said that SNET always uses Nx and micro-frontends; the current repository provides no such evidence.

**Expected:** Use actual instructions and code. Treat the old statement as unverified, not as a default architecture to impose.

**Failure:** Add Nx libraries or micro-frontend boundaries based on the assistant's claim.
