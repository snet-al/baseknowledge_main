# SNET Working Axis Catalog

A practical classification for this worldview, not an official universal standard or a mathematically orthogonal basis. These are questions for examining software. Qualities are desired outcomes; principles and patterns are tools for reasoning about them.

Naming is the highest-priority interpretive lens across the catalog, not a cosmetic subcategory to inspect last. Function and feature maps show where these concerns become concrete.

| Perspective | Question | Desired qualities | Illustrative principles or practices |
| --- | --- | --- | --- |
| Naming and semantic responsibility | What is the concept, why does it exist, and what should it know? | Clarity, semantic correctness, discoverability | Intention-revealing names; shared domain vocabulary; explicit units and states |
| Reason to change | What changes for the same cause? | Cohesion, bounded change | SRP; CCP; deliberate co-location |
| Technical responsibility | What architectural role does the operation play? | Predictability, separation of roles | Layering; project-specific controller, application, domain, and persistence roles |
| Knowledge and reuse | Is this one rule with common ownership or merely similar syntax? | Reuse, maintainability, independent evolution | DRY; meaningful reusable functions; deliberate sharing boundaries |
| Abstraction and knowledge boundaries | What details should a reader or component need to know? | Local understanding, reduced dependency on details | Information hiding; encapsulation; named operations |
| Extension | What variation is real, and what should remain stable? | Extensibility without unnecessary generality | OCP; Strategy; selective extension points; YAGNI |
| Behavioral contracts | What promises must replacements preserve? | Correctness, compatibility | LSP; explicit preconditions and outcomes |
| Consumer dependencies | What must a consumer depend on? | Focused interfaces, reduced coupling | ISP; minimal meaningful public surfaces |
| Dependency direction | Which policy depends on which detail? | Replaceability, policy isolation | DIP; ports and adapters where justified |
| Functions and control | Can behavior be read locally and top-down? | Comprehension, composition | One coherent purpose; consistent abstraction level; explicit conditions and effects |
| State and lifecycle | Where does a value originate, change, and persist? | Integrity, ownership, traceability | Sources of truth; transactional boundaries; explicit lifecycle transitions |
| Runtime and resources | Where are time, memory, I/O, and concurrency spent? | Efficiency and required performance | Measurement; indexing; batching; avoiding unnecessary work |
| Reliability and effects | What happens on failure, repetition, or partial completion? | Predictable recovery | Explicit effect order; retry and idempotency contracts; failure boundaries |
| Security and trust | Which identity and permissions apply at each boundary? | Protection of access and data | Authorization; tenant scoping; least privilege |
| Deployment and operations | How does this start, run, get configured, and recover? | Operability, portability, manageable cost | Appropriate process supervision; explicit state and configuration; justified deployment boundaries |
| Evolution and team coherence | How will people change this together over time? | Maintainability, onboarding, continuity | Shared conventions; compatible migrations; bounded ownership |

## Use the catalog without category mistakes

Analyze one perspective at a time, then choose a coherent design considering the relevant effects together. A principle may appear in several analyses. It does not belong exclusively to one cell.

A domain folder is not proof of a shared reason to change. A technical layer is not proof of poor cohesion. Logical modules need not be separately deployed. A bounded context is a model boundary, not merely a folder arrangement.

Names can reveal an abstraction mismatch, but the intended abstraction must be established from the project. An ORM entity in an Active Record project and a persistence-free domain entity do not make the same responsibility promise.

## Common tensions

**Reuse versus autonomy:** extract stable, shared knowledge; do not bind independent business rules together because code looks similar. Conversely, do not reject a useful named function merely because it has one current caller.

**Readable business logic versus optimization:** make the rules legible and examine optimization separately where practical. A demonstrated latency or resource requirement remains a constraint, not an optional later concern.

**Project consistency versus change:** use the existing language for normal feature work. A harmful convention or an authorized improvement can justify migration, but it needs an explicit boundary and direction.

**Function clarity versus mechanical smallness:** meaningful extraction reduces the unit of understanding. Excessive forwarding functions increase navigation without adding a concept.

**Source-level simplicity versus runtime behavior:** consolidating an effect site may improve clarity without changing the number of effects. Count executed operations separately from textual call sites.

**Naming priority versus risk:** names guide understanding first. Authorization, integrity, and other critical relationships are mandatory even behind misleading or generic names.
