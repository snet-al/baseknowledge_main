#!/usr/bin/env python3
"""Reinforce the SNET perception gate before every Codex user turn.

Codex sends one JSON event on stdin. This hook intentionally returns a short,
static developer-context reminder; AGENTS.md remains the source of truth.
"""

from __future__ import annotations

import json
import sys


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except Exception:
        event = {}

    hook_event = str(event.get("hook_event_name", "UserPromptSubmit"))

    reminder = (
        "SNET WORLDVIEW GATE FOR THIS TURN: Before any material answer or edit, "
        "apply the global AGENTS.md in this order: (1) naming and semantic truth, "
        "(2) multi-dimensional axes and trade-offs, (3) functions/value flow and "
        "their grouping, (4) build or update the task-scoped semantic feature map. "
        "Use exact prompt names as the task-vector seeds; inspect the complete "
        "task-relevant feature closure; map meaning-bearing variables, functions, "
        "typed relations, sources of truth, state, and side effects; rank exploration "
        "by naming first while verifying truth with code and runtime evidence. Do not "
        "act from the first matching file and do not introduce a second project language."
    )

    output = {
        "hookSpecificOutput": {
            "hookEventName": hook_event,
            "additionalContext": reminder,
        }
    }
    json.dump(output, sys.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
